import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms'; // IMPORTE ADICIONADO

interface Solicitacao {
  id: number;
  nome: string;
  cpf: string;
  dataNascimento: string;
  escolaridade: string;
  logradouro: string;
  numero: string;
  bairro: string;
  status: 'pendente' | 'aprovada' | 'reprovada';
  dataSolicitacao: string;
  dataAprovacao?: string;
  motivoReprovacao?: string;
}

@Component({
  selector: 'app-admin-pedidos',
  standalone: true,
  imports: [CommonModule, FormsModule], // FORMSMODULE ADICIONADO NOS IMPORTS
  templateUrl: './admin-pedidos.html',
  styleUrls: ['./admin-pedidos.css']
})
export class AdminPedidos implements OnInit {
  solicitacoes: Solicitacao[] = [];
  filtroStatus: string = 'todos';

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.carregarSolicitacoes();
  }

  carregarSolicitacoes(): void {
    const dados = localStorage.getItem('solicitacoes');
    this.solicitacoes = dados ? JSON.parse(dados) : [];
  }

  get solicitacoesFiltradas(): Solicitacao[] {
    if (this.filtroStatus === 'todos') {
      return this.solicitacoes;
    }
    return this.solicitacoes.filter(s => s.status === this.filtroStatus);
  }

  verDetalhes(id: number): void {
    this.router.navigate(['/admin/pedido', id]);
  }

  aprovarSolicitacao(solicitacao: Solicitacao): void {
    solicitacao.status = 'aprovada';
    solicitacao.dataAprovacao = new Date().toISOString();
    
    // Gerar número da carteirinha
    const carteirinha = {
      ...solicitacao,
      numeroCarteirinha: `CT${solicitacao.id.toString().padStart(6, '0')}`,
      validade: this.calcularValidade()
    };
    
    this.atualizarLocalStorage();
  }

  reprovarSolicitacao(solicitacao: Solicitacao, motivo: string): void {
    solicitacao.status = 'reprovada';
    solicitacao.motivoReprovacao = motivo;
    this.atualizarLocalStorage();
  }

  private calcularValidade(): string {
    const data = new Date();
    data.setFullYear(data.getFullYear() + 1);
    return data.toISOString().split('T')[0];
  }

  private atualizarLocalStorage(): void {
    localStorage.setItem('solicitacoes', JSON.stringify(this.solicitacoes));
  }

  formatarData(data: string): string {
    return new Date(data).toLocaleDateString('pt-BR');
  }

  getTotalPorStatus(status: string): number {
    return this.solicitacoes.filter(s => s.status === status).length;
  }
}