import { Routes } from '@angular/router';
import { Home } from './home/home';
import { SolicitarCarteirinha } from './solicitar-carteirinha/solicitar-carteirinha';
import { MinhaCarteirinha } from './minha-carteirinha/minha-carteirinha';
import { NormasUso } from './normas-uso/normas-uso';
import { AdminPedidos } from './admin-pedidos/admin-pedidos';
import { AdminDetalhes } from './admin-detalhes/admin-detalhes';
import { Login } from './login/login';

export const routes: Routes = [
  { path: '', component: Home },
  { path: 'solicitar', component: SolicitarCarteirinha },
  { path: 'minha-carteirinha', component: MinhaCarteirinha },
  { path: 'normas-uso', component: NormasUso },
  { path: 'admin/pedidos', component: AdminPedidos },
  { path: 'admin/pedido/:id', component: AdminDetalhes },
  { path: 'login', component: Login },
  { path: '**', redirectTo: '' }
];