import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import html2canvas from 'html2canvas';

interface StudentCardData {
  id: string;
  studentName: string;
  registrationNumber: string;
  issueDate: string;
  expirationDate: string;
  status: 'active' | 'expired' | 'pending' | 'rejected';
  photoUrl?: string;
  course: string;
  institution: string;
  birthDate: string;
  cpf: string;
}

@Component({
  selector: 'app-student-card',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './student-card.html',
  styleUrls: ['./student-card.css']
})
export class StudentCard implements OnInit {
  @ViewChild('studentCard', { static: false }) studentCardElement!: ElementRef;
  
  card: StudentCardData | null = null;
  studentEmail: string = '';
  isDownloading: boolean = false;

  constructor(private router: Router) {}

  ngOnInit() {
    const user = localStorage.getItem('currentUser');
    if (!user || JSON.parse(user).type !== 'student') {
      this.router.navigate(['/login']);
      return;
    }

    this.studentEmail = JSON.parse(user).email;
    this.loadCard();
  }

  loadCard() {
    const savedCard = localStorage.getItem(`card_${this.studentEmail}`);
    if (savedCard) {
      this.card = JSON.parse(savedCard);
    } else {
      this.router.navigate(['/student-dashboard']);
    }
  }

  async downloadCard() {
    if (!this.card || this.isDownloading) return;

    this.isDownloading = true;
    
    try {
      // Aguardar um pouco para garantir que o DOM esteja renderizado
      await new Promise(resolve => setTimeout(resolve, 500));

      const cardElement = this.studentCardElement.nativeElement;
      
      // Configurações para melhor qualidade da imagem
      const canvas = await html2canvas(cardElement, {
        scale: 3, // Alta resolução
        useCORS: true,
        allowTaint: true,
        backgroundColor: null,
        logging: false,
        width: cardElement.offsetWidth,
        height: cardElement.offsetHeight,
        onclone: (clonedDoc) => {
          // Garantir que o elemento clonado tenha o mesmo estilo
          const clonedCard = clonedDoc.getElementById('student-card');
          if (clonedCard) {
            clonedCard.style.boxShadow = 'none';
            clonedCard.style.margin = '0';
            clonedCard.style.border = '2px solid #000';
          }
        }
      });

      // Converter canvas para blob
      canvas.toBlob((blob) => {
        if (blob) {
          // Criar URL para download
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.download = `carteirinha_${this.card?.studentName.replace(/\s+/g, '_')}_${this.card?.registrationNumber}.png`;
          link.href = url;
          
          // Disparar o download
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          
          // Liberar a URL
          URL.revokeObjectURL(url);
          
          alert('Carteirinha baixada com sucesso!');
        } else {
          throw new Error('Falha ao gerar a imagem da carteirinha');
        }
      }, 'image/png', 1.0); // Qualidade máxima

    } catch (error) {
      console.error('Erro ao baixar carteirinha:', error);
      alert('Erro ao baixar a carteirinha. Tente novamente.');
    } finally {
      this.isDownloading = false;
    }
  }

  hasPhoto(): boolean {
    return !!this.card?.photoUrl;
  }

  getPhotoUrl(): string {
    return this.card?.photoUrl || '';
  }

  logout() {
    localStorage.removeItem('currentUser');
    this.router.navigate(['/login']);
  }
}