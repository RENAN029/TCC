import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CarteirinhaDisplay } from '../carteirinha-display/carteirinha-display'; // IMPORTE ADICIONADO

interface Carteirinha {
  id: number;
  nome: string;
  cpf: string;
  dataNascimento: string;
  escolaridade: string;
  logradouro: string;
  numero: string;
  bairro: string;
  status: 'pendente' | 'aprovada' | 'reprovada';
  dataSolicitacao: string;
  dataAprovacao?: string;
  validade?: string;
  numeroCarteirinha?: string;
}

@Component({
  selector: 'app-minha-carteirinha',
  standalone: true,
  imports: [CommonModule, CarteirinhaDisplay], // COMPONENTE ADICIONADO NOS IMPORTS
  templateUrl: './minha-carteirinha.html',
  styleUrls: ['./minha-carteirinha.css']
})
export class MinhaCarteirinha implements OnInit {
  carteirinhas: Carteirinha[] = [];
  carteirinhaAtiva: Carteirinha | null = null;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.carregarCarteirinhas();
  }

  carregarCarteirinhas(): void {
    const solicitacoes = JSON.parse(localStorage.getItem('solicitacoes') || '[]');
    this.carteirinhas = solicitacoes;
    
    // Encontrar carteirinha ativa (aprovada e dentro da validade)
    this.carteirinhaAtiva = this.carteirinhas.find(c => 
      c.status === 'aprovada' && 
      (!c.validade || new Date(c.validade) > new Date())
    ) || null;
  }

  solicitarNova(): void {
    this.router.navigate(['/solicitar']);
  }

  calcularValidade(dataAprovacao: string): string {
    const data = new Date(dataAprovacao);
    data.setFullYear(data.getFullYear() + 1);
    return data.toISOString().split('T')[0];
  }

  formatarData(data: string): string {
    return new Date(data).toLocaleDateString('pt-BR');
  }

  diasParaExpirar(validade: string): number {
    const hoje = new Date();
    const dataValidade = new Date(validade);
    const diff = dataValidade.getTime() - hoje.getTime();
    return Math.ceil(diff / (1000 * 3600 * 24));
  }

  imprimirCarteirinha(): void {
    window.print();
  }
}