import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MinhaCarteirinha } from './minha-carteirinha';

describe('MinhaCarteirinha', () => {
  let component: MinhaCarteirinha;
  let fixture: ComponentFixture<MinhaCarteirinha>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MinhaCarteirinha]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MinhaCarteirinha);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
