import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Carteirinha {
  id: number;
  nome: string;
  cpf: string;
  dataNascimento: string;
  escolaridade: string;
  logradouro: string;
  numero: string;
  bairro: string;
  status: string;
  dataSolicitacao: string;
  dataAprovacao?: string;
  validade?: string;
  numeroCarteirinha?: string;
}

@Component({
  selector: 'app-carteirinha-display',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './carteirinha-display.html',
  styleUrls: ['./carteirinha-display.css']
})
export class CarteirinhaDisplay {
  @Input() carteirinha!: Carteirinha; // ← Aqui está correto: "carteirinha"

  gerarNumeroCarteirinha(): string {
    if (this.carteirinha.numeroCarteirinha) {
      return this.carteirinha.numeroCarteirinha;
    }
    
    const id = this.carteirinha.id.toString().padStart(6, '0');
    const cpf = this.carteirinha.cpf.substring(0, 6);
    return `CT${id}${cpf}`;
  }

  calcularIdade(dataNascimento: string): number {
    const hoje = new Date();
    const nascimento = new Date(dataNascimento);
    let idade = hoje.getFullYear() - nascimento.getFullYear();
    
    const mesAtual = hoje.getMonth();
    const mesNascimento = nascimento.getMonth();
    
    if (mesAtual < mesNascimento || 
        (mesAtual === mesNascimento && hoje.getDate() < nascimento.getDate())) {
      idade--;
    }
    
    return idade;
  }

  formatarData(data: string): string {
    return new Date(data).toLocaleDateString('pt-BR');
  }
}