import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarteirinhaDisplay } from './carteirinha-display';

describe('CarteirinhaDisplay', () => {
  let component: CarteirinhaDisplay;
  let fixture: ComponentFixture<CarteirinhaDisplay>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CarteirinhaDisplay]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CarteirinhaDisplay);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
