import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-normas-uso',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './normas-uso.html',
  styleUrls: ['./normas-uso.css']
})
export class NormasUso {}