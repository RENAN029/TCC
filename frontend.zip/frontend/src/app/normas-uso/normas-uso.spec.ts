import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NormasUso } from './normas-uso';

describe('NormasUso', () => {
  let component: NormasUso;
  let fixture: ComponentFixture<NormasUso>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NormasUso]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NormasUso);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
