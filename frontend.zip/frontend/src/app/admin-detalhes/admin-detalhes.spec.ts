import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminDetalhes } from './admin-detalhes';

describe('AdminDetalhes', () => {
  let component: AdminDetalhes;
  let fixture: ComponentFixture<AdminDetalhes>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminDetalhes]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminDetalhes);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
