import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CarteirinhaDisplay } from '../carteirinha-display/carteirinha-display'; // IMPORTE ADICIONADO

interface Solicitacao {
  id: number;
  nome: string;
  genero: string;
  dataNascimento: string;
  cpf: string;
  escolaridade: string;
  logradouro: string;
  numero: string;
  bairro: string;
  status: 'pendente' | 'aprovada' | 'reprovada';
  dataSolicitacao: string;
  dataAprovacao?: string;
  motivoReprovacao?: string;
  documentoMatricula?: string;
  foto?: string;
}

@Component({
  selector: 'app-admin-detalhes',
  standalone: true,
  imports: [CommonModule, FormsModule, CarteirinhaDisplay], // COMPONENTE ADICIONADO NOS IMPORTS
  templateUrl: './admin-detalhes.html',
  styleUrls: ['./admin-detalhes.css']
})
export class AdminDetalhes implements OnInit {
  solicitacao: Solicitacao | null = null;
  motivoReprovacao = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.carregarSolicitacao();
  }

  carregarSolicitacao(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    const solicitacoes: Solicitacao[] = JSON.parse(localStorage.getItem('solicitacoes') || '[]');
    this.solicitacao = solicitacoes.find(s => s.id === id) || null;
  }

  aprovar(): void {
    if (this.solicitacao) {
      this.solicitacao.status = 'aprovada';
      this.solicitacao.dataAprovacao = new Date().toISOString();
      this.atualizarLocalStorage();
      this.router.navigate(['/admin/pedidos']);
    }
  }

  reprovar(): void {
    if (this.solicitacao && this.motivoReprovacao) {
      this.solicitacao.status = 'reprovada';
      this.solicitacao.motivoReprovacao = this.motivoReprovacao;
      this.atualizarLocalStorage();
      this.router.navigate(['/admin/pedidos']);
    }
  }

  private atualizarLocalStorage(): void {
    const solicitacoes: Solicitacao[] = JSON.parse(localStorage.getItem('solicitacoes') || '[]');
    const index = solicitacoes.findIndex(s => s.id === this.solicitacao!.id);
    if (index !== -1) {
      solicitacoes[index] = this.solicitacao!;
      localStorage.setItem('solicitacoes', JSON.stringify(solicitacoes));
    }
  }

  voltar(): void {
    this.router.navigate(['/admin/pedidos']);
  }

  calcularIdade(dataNascimento: string): number {
    const hoje = new Date();
    const nascimento = new Date(dataNascimento);
    let idade = hoje.getFullYear() - nascimento.getFullYear();
    
    const mesAtual = hoje.getMonth();
    const mesNascimento = nascimento.getMonth();
    
    if (mesAtual < mesNascimento || 
        (mesAtual === mesNascimento && hoje.getDate() < nascimento.getDate())) {
      idade--;
    }
    
    return idade;
  }

  formatarData(data: string): string {
    return new Date(data).toLocaleDateString('pt-BR');
  }
}