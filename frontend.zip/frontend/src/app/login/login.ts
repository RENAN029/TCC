import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class Login {
  credentials = {
    email: '',
    password: ''
  };
  
  loading = false;
  error = '';

  constructor(private router: Router) {}

  onSubmit(): void {
    this.loading = true;
    this.error = '';

    // Simulação de login (em produção, isso viria do backend)
    setTimeout(() => {
      if (this.credentials.email === 'admin@municipio.gov.br' && 
          this.credentials.password === 'admin123') {
        
        localStorage.setItem('authToken', 'simulated-token');
        localStorage.setItem('userRole', 'admin');
        this.router.navigate(['/admin/pedidos']);
      } else {
        this.error = 'Credenciais inválidas. Tente novamente.';
      }
      this.loading = false;
    }, 1500);
  }
}