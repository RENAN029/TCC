import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

interface Estudante {
  nome: string;
  genero: string;
  dataNascimento: string;
  cpf: string;
  escolaridade: string;
  logradouro: string;
  numero: string;
  bairro: string;
  documentoMatricula: File | null;
  foto: File | null;
}

@Component({
  selector: 'app-solicitar-carteirinha',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './solicitar-carteirinha.html',
  styleUrls: ['./solicitar-carteirinha.css']
})
export class SolicitarCarteirinha {
  estudante: Estudante = {
    nome: '',
    genero: '',
    dataNascimento: '',
    cpf: '',
    escolaridade: '',
    logradouro: '',
    numero: '',
    bairro: '',
    documentoMatricula: null,
    foto: null
  };

  passoAtual = 1;
  enviado = false;

  constructor(private router: Router) {}

  avancarPasso(): void {
    if (this.passoAtual < 3) {
      this.passoAtual++;
    }
  }

  voltarPasso(): void {
    if (this.passoAtual > 1) {
      this.passoAtual--;
    }
  }

  onFileChange(event: any, campo: 'documentoMatricula' | 'foto'): void {
    const file = event.target.files[0];
    if (file) {
      this.estudante[campo] = file;
    }
  }

  // NOVO MÉTODO: Formatar CPF removendo caracteres não numéricos
  formatarCPFInput(event: any): void {
    let value = event.target.value;
    // Remove tudo que não é número
    value = value.replace(/\D/g, '');
    // Atualiza o valor no model
    this.estudante.cpf = value;
    // Atualiza o valor no input com a formatação visual
    if (value.length <= 11) {
      event.target.value = this.formatarCPF(value);
    }
  }

  // Método para formatação visual do CPF
  formatarCPF(cpf: string): string {
    cpf = cpf.replace(/\D/g, '');
    if (cpf.length <= 3) {
      return cpf;
    } else if (cpf.length <= 6) {
      return cpf.replace(/(\d{3})(\d{0,3})/, '$1.$2');
    } else if (cpf.length <= 9) {
      return cpf.replace(/(\d{3})(\d{3})(\d{0,3})/, '$1.$2.$3');
    } else {
      return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{0,2})/, '$1.$2.$3-$4');
    }
  }

  onSubmit(): void {
    // Simular envio para o backend
    console.log('Dados enviados:', this.estudante);
    
    // Salvar no localStorage para demonstração
    const solicitacoes = JSON.parse(localStorage.getItem('solicitacoes') || '[]');
    solicitacoes.push({
      ...this.estudante,
      id: Date.now(),
      status: 'pendente',
      dataSolicitacao: new Date().toISOString()
    });
    localStorage.setItem('solicitacoes', JSON.stringify(solicitacoes));
    
    this.enviado = true;
    setTimeout(() => {
      this.router.navigate(['/minha-carteirinha']);
    }, 3000);
  }
}