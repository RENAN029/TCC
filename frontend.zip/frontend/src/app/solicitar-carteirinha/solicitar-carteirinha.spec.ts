import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SolicitarCarteirinha } from './solicitar-carteirinha';

describe('SolicitarCarteirinha', () => {
  let component: SolicitarCarteirinha;
  let fixture: ComponentFixture<SolicitarCarteirinha>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SolicitarCarteirinha]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SolicitarCarteirinha);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
