import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterModule } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterModule],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {
  title = 'Carteirinha Estudantil';

  isLoggedIn(): boolean {
    const user = localStorage.getItem('currentUser');
    return !!user;
  }

  isStudent(): boolean {
    const user = localStorage.getItem('currentUser');
    if (!user) return false;
    return JSON.parse(user).type === 'student';
  }

  isAdmin(): boolean {
    const user = localStorage.getItem('currentUser');
    if (!user) return false;
    return JSON.parse(user).type === 'admin';
  }

  logout(): void {
    localStorage.removeItem('currentUser');
    window.location.href = '/login';
  }
}